function [x_top,y_top] = displace_atom(All_phase_type_select,All_events_select,All_move_atom_id_select,x_top,y_top)
    if All_phase_type_select == 0
        if All_events_select == 1
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) + 4.05563/2; 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select);
        elseif All_events_select == 2
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) - 4.05563/2*sind(30); 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select) + 4.05563/2*cosd(30);
        elseif All_events_select == 3
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) - 4.05563/2*sind(30); 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select) - 4.05563/2*cosd(30);
        end
    elseif All_phase_type_select == 1
        if All_events_select == 1
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) - 4.05563/2; 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select);
        elseif All_events_select == 2
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) + 4.05563/2*sind(30); 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select) + 4.05563/2*cosd(30);
        elseif All_events_select == 3
            x_top(All_move_atom_id_select) = x_top(All_move_atom_id_select) + 4.05563/2*sind(30); 
            y_top(All_move_atom_id_select) = y_top(All_move_atom_id_select) - 4.05563/2*cosd(30);
        end
    end
end