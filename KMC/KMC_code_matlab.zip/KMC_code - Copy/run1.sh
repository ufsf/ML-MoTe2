#!/bin/bash
#SBATCH --job-name="EAM-HEA"
#SBATCH --account=research-me-mse
#SBATCH --partition=compute
#SBATCH -t 5:00:00
#SBATCH --ntasks=1
#SBATCH --mem-per-cpu=1G

module load matlab

srun matlab -batch "run('PrepareAllTsites1.m'); exit;"



