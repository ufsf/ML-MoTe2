function phase_type = check_phase_type(x_i,y_i,x_bottom,y_bottom)
    dist = (x_i-x_bottom).^2+(y_i-y_bottom).^2;
    index = find(dist<0.5^2, 1);
    if ~isempty(index)
        phase_type = 0; % 2H phase
    else
        phase_type  = 1; % 1T' phase
    end
end