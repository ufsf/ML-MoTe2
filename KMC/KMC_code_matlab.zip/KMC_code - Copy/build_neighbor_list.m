function [neighbor_index,num_neigh] = build_neighbor_list(x_top,y_top,All_move_atom_id_select,...
    neight_list_old,num_neigh_old)
    xmax = max(x_top);
    xmin = min(x_top);
    ymax = max(y_top);
    ymin = min(y_top);
    neighbor_index = neight_list_old;
    num_neigh = num_neigh_old;
    if All_move_atom_id_select<=0
        for i = 1:length(x_top)
            x_top_i = x_top(i);
            y_top_i = y_top(i);
            dist = (x_top_i-x_top).^2+(y_top_i-y_top).^2;
            index = find(dist<3.55^2);
            neighbor_index{i} = setdiff(index,i);
            if x_top_i < xmax-10 && x_top_i > xmin+10 && y_top_i < ymax-10 && y_top_i > ymin+10 
                num_neigh(i) = length(neighbor_index{i});
            else
                num_neigh(i) = 6;
            end
        end
    else
        myx = x_top(All_move_atom_id_select);
        myy = y_top(All_move_atom_id_select);
        dist = (myx-x_top).^2+(myy-y_top).^2;
        index = find(dist < 10^2);
        for i = 1:length(index)
            x_top_i = x_top(index(i));
            y_top_i = y_top(index(i));
            dist = (x_top_i-x_top).^2+(y_top_i-y_top).^2;
            new_index = find(dist<3.55^2);
            neighbor_index{index(i)} = setdiff(new_index,index(i));
            num_neigh(index(i)) = length(neighbor_index{index(i)});
        end
    end
end