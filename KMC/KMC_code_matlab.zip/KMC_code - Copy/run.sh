#!/bin/bash
#SBATCH --job-name="EAM-HEA"
#SBATCH --account=research-me-mse
#SBATCH --partition=compute
#SBATCH -t 10:00:00
#SBATCH --ntasks=1
#SBATCH --mem-per-cpu=6G

module load matlab

srun matlab -batch "run('create_vac_rdf.m'); exit;"



