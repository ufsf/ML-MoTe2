function [atom,bounds] = read_data(filename)
% filename = 'LU1/1-relax.data';

% Open the file for reading
fid = fopen(filename, 'r');

% Read and discard the first 6 header lines
fgetl(fid);

% Read the number of atoms and atom types
line = fgetl(fid);
data = str2double(strsplit(line));
num_atoms = data(1);
% num_atom_types = data(2);

fgetl(fid);
%%
line = fgetl(fid);
data = str2double(strsplit(line));
xlow = data(1);
xhi = data(2);

line = fgetl(fid);
data = str2double(strsplit(line));
ylow = data(1);
yhi = data(2);

line = fgetl(fid);
data = str2double(strsplit(line));
zlow = data(1);
zhi = data(2);

bounds = [xlow ylow zlow; xhi yhi zhi];
% Read and discard the "Masses" section
for i = 1:3
    fgetl(fid);
end
% Initialize arrays to store atom data

atom = zeros(num_atoms,5);
for i = 1:num_atoms
    data = str2double(strsplit(fgetl(fid)));
    atom(i,1) = data(1);
    atom(i,2) = data(2);
    atom(i,3) = data(3);
    atom(i,4) = data(4);
    atom(i,5) = data(5);
end
% Close the file
fclose(fid);

