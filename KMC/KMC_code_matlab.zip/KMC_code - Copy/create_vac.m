clc;
clear;
%% \NC-DFT-MoTe2\Vacancy_line\make_config_matlab
generate_vac = 1;
if generate_vac == 1
    [atom_ini,bounds] = read_data('VIP-backup/ini-large.data');
    % write_data('my.data',atom',bounds);
    %% Create random mono-vacancies
    for irepeat = 1:1
        % ini
        % pt1 = [16.2251 9.62594];
        % pt2 = [1.01658 0.845483];
        % pt3 = [16.2251 -7.93532];
    
        % ini-large
        pt1 = [293.021 7.86999];
        pt2 = [277.812 -0.910814];
        pt3 = [293.021 -9.69127];

        % ini-super
        % pt1 = [1056.49 9.62594];
        % pt2 = [1041.28 0.845483];
        % pt3 = [1056.49 -7.93532];

        atom = atom_ini;
        x = atom(:,3);
        y = atom(:,4);
        z = atom(:,5);
        index_top = find(z>16);
        Num_Vac = 140; % N/2 is the number of divacancy
        x_v = [];
        y_v = [];
        %%
        istep = 1;
        while istep<=Num_Vac
            len_x = pt1(1)-pt2(1);
            n = round(len_x/3.04171);
            % disp(n);
            N_possible = ((n+1)+(n+2))*2;
            final_index = get_index_inside(x,y,z,pt1,pt2,pt3);
        
            belong_group = final_index.belong_group;
            all_index = final_index.all_index;
            select_vac_global_index = final_index.select_vac_global_index;
        
            x_v_tmp = x(select_vac_global_index);
            y_v_tmp = y(select_vac_global_index);
        
            if istep > 1
                dis_tmp = ((x_v_tmp-x_v).^2+(y_v_tmp-y_v).^2).^0.5;
                index_tmp = find(dis_tmp<4);
            
                if ~isempty(index_tmp)
                    continue;
                end
            end
            % if istep ==6
            %     pause(1);
            % end
            x_v(istep) = x(select_vac_global_index);
            y_v(istep) = y(select_vac_global_index);
        
        
            if belong_group ==1||belong_group==2
                curr_index = all_index{1};
            else
                curr_index = all_index{3};
            end
        
            x_tmp = x(curr_index);
            [~,index_tmp] = max(x_tmp);
        
            x(curr_index) = x(curr_index) + 2;
            remain_index = setdiff(1:length(x),curr_index(index_tmp));
            atom = atom(remain_index,:);
            x = x(remain_index);
            y = y(remain_index);
            z = z(remain_index);
            atom(:,3) = x;
            %% update cooridates of transitioned region
            if belong_group ==1||belong_group==2
                pt1(1) = pt1(1);
                pt1(2) = pt1(2)+3.51225;
                pt2(1) = pt2(1)-3.04171;
                pt2(2) = pt2(2)+1.7563;
                pt3(1) = pt3(1);
                pt3(2) = pt3(2);
            else
                pt1(1) = pt1(1);
                pt1(2) = pt1(2);
                pt2(1) = pt2(1)-3.04171;
                pt2(2) = pt2(2)-1.7563;
                pt3(1) = pt3(1);
                pt3(2) = pt3(2)-3.51225;
            end
            %%
            % folder = 'test/';
            % write_data([folder,num2str(istep),'.data'],atom',bounds);
            istep = istep + 1;
            disp(istep);
        end
        x_all = atom_ini(:,3);
        y_all = atom_ini(:,4);
        z_all = atom_ini(:,5);
        index_all = [];
        for i = 1:length(x_v)
            xi = x_v(i);
            yi = y_v(i);
            tmp = (x_all - xi).^2+(y_all - yi).^2;
            indexi_1 = find(tmp<1e-4);
            indexi_2 = find(z_all>15);
            indexi = intersect(indexi_1,indexi_2);
            index_all = [indexi index_all];
        end
        index_rest = setdiff(1:length(atom_ini),index_all);
        write_data(['defect-large-',num2str(irepeat),'.data'],atom_ini(index_rest,:)',bounds);
    end
end