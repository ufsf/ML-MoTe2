clc;
clear;
%%
Line = load('line/res.mat');
Line = Line.Res;

vac = load('vac/res.mat');
vac = vac.Res;

area_max = 44^2/4*3^0.5;

%%
figure;
hold on;
y1 = (Line.PT_size_Store)/max(Line.PT_size_Store)*area_max;
y2 = (vac.PT_size_Store(1:end-7))/max(vac.PT_size_Store(1:end-7))*area_max;
plot(vac.Time_store(1:end-8)*1e3,y2,'-b','LineWidth',3);
plot(Line.Time_store(1:end-1)*1e3,y1,'-r','LineWidth',3);
my_plot_setting;
% legend('random MV','Vacancy line');

