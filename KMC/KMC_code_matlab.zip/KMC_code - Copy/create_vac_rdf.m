clc;
clear;
%% \NC-DFT-MoTe2\Vacancy_line\make_config_matlab
%%
% [atom_ini,bounds] = read_data('ini-super-350.data');
% write_data('my.data',atom',bounds);
atom_ini = load('../ini-super-350.data');
bounds = load('../box.txt');
bounds = bounds';
%%
rng('shuffle');
Vac = [];
for irepeat = 1:10
    pt1 = [1731.75 9.62594];
    pt2 = [1716.54 0.845483];
    pt3 = [1731.75 -7.93532];
    atom = atom_ini;
    x = atom(:,3);
    y = atom(:,4);
    z = atom(:,5);
    index_top = find(z>16);
    Num_Vac = 900; %  number of divacancy
    x_v = [];
    y_v = [];
    %%
    istep = 1;
    while istep<=Num_Vac
        len_x = pt1(1)-pt2(1);
        n = round(len_x/3.04171);
        disp(n);
        N_possible = ((n+1)+(n+2))*2;
        final_index = get_index_inside(x,y,z,pt1,pt2,pt3);
    
        belong_group = final_index.belong_group;
        all_index = final_index.all_index;
        select_vac_global_index = final_index.select_vac_global_index;
    
        x_v_tmp = x(select_vac_global_index);
        y_v_tmp = y(select_vac_global_index);
    
        if istep > 1
            dis_tmp = ((x_v_tmp-x_v).^2+(y_v_tmp-y_v).^2).^0.5;
            index_tmp = find(dis_tmp<1e-2);
        
            if ~isempty(index_tmp)
                continue;
            end
        end
        % if istep ==6
        %     pause(1);
        % end
        x_v(istep) = x(select_vac_global_index);
        y_v(istep) = y(select_vac_global_index);
    
    
        if belong_group ==1||belong_group==2
            curr_index = all_index{1};
        else
            curr_index = all_index{3};
        end
    
        x_tmp = x(curr_index);
        [~,index_tmp] = max(x_tmp);
    
        x(curr_index) = x(curr_index) + 2;
        remain_index = setdiff(1:length(x),curr_index(index_tmp));
        atom = atom(remain_index,:);
        x = x(remain_index);
        y = y(remain_index);
        z = z(remain_index);
        atom(:,3) = x;
        %% update cooridates of transitioned region
        if belong_group ==1||belong_group==2
            pt1(1) = pt1(1);
            pt1(2) = pt1(2)+3.51225;
            pt2(1) = pt2(1)-3.04171;
            pt2(2) = pt2(2)+1.7563;
            pt3(1) = pt3(1);
            pt3(2) = pt3(2);
        else
            pt1(1) = pt1(1);
            pt1(2) = pt1(2);
            pt2(1) = pt2(1)-3.04171;
            pt2(2) = pt2(2)-1.7563;
            pt3(1) = pt3(1);
            pt3(2) = pt3(2)-3.51225;
        end
        %%
        % if istep==Num_Vac
        %     folder = 'test/';
        %     write_data([folder,num2str(istep),'.data'],atom',bounds);
        % end
        istep = istep + 1;
    end
    Vac{irepeat}.x_v = x_v;
    Vac{irepeat}.y_v = y_v;
    save("Vac.mat","Vac");
    disp(irepeat);
end
%%
