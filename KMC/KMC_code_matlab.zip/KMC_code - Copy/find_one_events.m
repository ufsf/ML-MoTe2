function [Events, All_type, All_id] = find_one_events(x_i,y_i,x_neigh,y_neigh,x_bottom,y_bottom,curr_id)
    Events = [];
    All_type = [];
    All_id = [];
    phase_type = check_phase_type(x_i,y_i,x_bottom,y_bottom);
    if phase_type == 0 % for the active Te atom in 2H phase
        x_i1 = x_i + 4.05563/2;
        y_i1 = y_i;
        dist_tmp = (x_i1 - x_neigh).^2+(y_i1 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 1];
            All_type = [All_type 0];
            All_id  = [All_id curr_id];
        end

        x_i2 = x_i - 4.05563/2*sind(30);
        y_i2 = y_i + 4.05563/2*cosd(30);

        dist_tmp = (x_i2 - x_neigh).^2+(y_i2 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 2];
            All_type = [All_type 0];
            All_id  = [All_id curr_id];
        end

        x_i3 = x_i - 4.05563/2*sind(30);
        y_i3 = y_i - 4.05563/2*cosd(30);
        dist_tmp = (x_i3 - x_neigh).^2+(y_i3 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 3];
            All_type = [All_type 0];
            All_id  = [All_id curr_id];
        end

    elseif phase_type == 1 % for the active Te atom in 1T' phase
        x_i1 = x_i - 4.05563/2;
        y_i1 = y_i;
        dist_tmp = (x_i1 - x_neigh).^2+(y_i1 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 1];
            All_type = [All_type 1];
            All_id  = [All_id curr_id];
        end

        x_i2 = x_i + 4.05563/2*sind(30);
        y_i2 = y_i + 4.05563/2*cosd(30);

        dist_tmp = (x_i2 - x_neigh).^2+(y_i2 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 2];
            All_type = [All_type 1];
            All_id  = [All_id curr_id];
        end

        x_i3 = x_i + 4.05563/2*sind(30);
        y_i3 = y_i - 4.05563/2*cosd(30);
        dist_tmp = (x_i3 - x_neigh).^2+(y_i3 - y_neigh).^2;
        if sum(dist_tmp<2.5^2)<1
            Events = [Events 3];
            All_type = [All_type 1];
            All_id  = [All_id curr_id];
        end
    end
end