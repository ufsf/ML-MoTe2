function final_index = get_index_new(x,y,z,pt1,pt2,pt3)
index_top = find(z>16);
rng('shuffle');
%% group1
xv1 = [pt1(1) pt2(1) pt3(1) pt1(1)];
yv1 = [pt1(2) pt2(2) pt3(2) pt1(2)];
[in,~] = inpolygon(x,y,xv1,yv1);
index_in = find(in==1);
final_index = intersect(index_top,index_in);