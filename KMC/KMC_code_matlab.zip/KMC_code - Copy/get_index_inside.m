function final_index = get_index_inside(x,y,z,pt1,pt2,pt3)
index_top = find(z>16);
rng('shuffle');
%% group1
xv1 = [pt1(1)+0.5 pt1(1)+0.5 pt2(1)-3.5417 pt2(1)-3.5417 pt1(1)+0.5];
yv1 = [pt1(2)+1.7561 pt1(2)+5.2684 pt2(2)+3.51225 pt2(2) pt1(2)+1.7561];
[in,~] = inpolygon(x,y,xv1,yv1);
index_in = find(in==1);
index_group1 = intersect(index_top,index_in);
%% group2
% xv2 = [pt1(1)-1.7561 pt1(1)-1.7561 pt2(1)-3.5417 pt2(1)-3.5417 pt1(1)-1.7561];
% yv2 = [pt1(2)+5.2684 pt1(2)+8.7806 pt2(2)+3.51225*2 pt2(2)+3.51225 pt1(2)+5.2684];
% [in,~] = inpolygon(x,y,xv2,yv2);
% index_in = find(in==1);
% index_group2 = intersect(index_top,index_in);
index_group2 = [];
%% group3
xv3 = [pt3(1)+0.5 pt3(1)+0.5 pt2(1)-3.5417 pt2(1)-3.5417 pt3(1)+0.5];
yv3 = [pt3(2)-5.2684 pt3(2)-1.7561  pt2(2) pt2(2)-3.51225 pt3(2)-5.2684];
[in,~] = inpolygon(x,y,xv3,yv3);
index_in = find(in==1);
index_group3 = intersect(index_top,index_in);
%% group4
% xv2 = [pt3(1)-1.7561 pt3(1)-1.7561 pt2(1)-3.5417 pt2(1)-3.5417 pt3(1)-1.7561];
% yv2 = [pt3(2)-8.7806 pt3(2)-5.2684 pt2(2)-3.51225 pt2(2)-3.51225*2 pt3(2)-8.7806];
% [in,~] = inpolygon(x,y,xv2,yv2);
% index_in = find(in==1);
% index_group4 = intersect(index_top,index_in);
index_group4 = [];
%%
index_all = [index_group1;index_group2;index_group3;index_group4];
N_possible = length(index_all);
select_vac_local_index = randperm(N_possible,1);
select_vac_global_index = index_all(select_vac_local_index);
tmp1 = ismember(select_vac_global_index,index_group1);
tmp2 = ismember(select_vac_global_index,index_group2);
tmp3 = ismember(select_vac_global_index,index_group3);
tmp4 = ismember(select_vac_global_index,index_group4);

if tmp1==1
    belong_group = 1;
elseif tmp2==1
    % belong_group = 2;
    error('wrong!');
elseif tmp3==1
     belong_group = 3;
elseif tmp4==1
     error('wrong!');
     % belong_group = 4;
end
final_index.belong_group = belong_group;
final_index.select_vac_global_index = select_vac_global_index;
all_index{1} = index_group1;
all_index{2} = index_group2;
all_index{3} = index_group3;
all_index{4} = index_group4;
final_index.all_index = all_index;
end