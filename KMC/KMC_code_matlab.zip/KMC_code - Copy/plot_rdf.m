clc;
clear;
%%
x_all = [];
y_all = [];
for i = 1:50
    itmp = load(['res-1st/',num2str(i),'-Vac.mat']);
    itmp = itmp.Vac;
    for j = 1:length(itmp)
        jtmp = itmp{j};
        x_all = [x_all jtmp.x_v];
        y_all = [y_all jtmp.y_v];
    end
    disp(i);
end
%%
figure;
plot(x_all,y_all,'.');
axis equal;
my_plot_setting;
%%
Repeat = length(x_all)/900;

nx1 = 8;
ny1 = 14;

lx = 6.08342*nx1;
ly = 3.51225*ny1;

% XList=linspace(min(x_all),max(x_all),n);
XList = min(x_all):lx:max(x_all);
dx = diff(XList);
nx = length(XList);

% YList=linspace(min(y_all),max(y_all),n);
YList = min(y_all):ly:max(y_all);
dy = diff(YList);
ny = length(YList);

area = dx(1)*dy(1)*0.01; % nm^2

[XMesh,YMesh]=meshgrid(XList(2:end),YList(2:end));
Density = zeros(nx-1,ny-1)*nan;
for i = 1:nx-1
    for j = 1:ny-1
        ix1 = XList(i);
        ix2 = XList(i+1);
        index1 = find(x_all>ix1);
        index2 = find(x_all<ix2);
        index_x = intersect(index1,index2);
        jy1 = YList(j);
        jy2 = YList(j+1);
        index1 = find(y_all>jy1);
        index2 = find(y_all<jy2);
        index_y = intersect(index1,index2);
        index = intersect(index_x,index_y);
        if ~isempty(index)
            Density(i,j) = length(index)/Repeat;
        end
    end
    disp(i);
end
Density = Density/(nx1*ny1*4);
% save("Density.mat","Density");
%%
% 使用scatter绘图
% my_index = find(~isnan(Density));
% my_Density = Density(my_index);
Density_smooth = smoothdata(Density,1,'gaussian',10);
Density_smooth = smoothdata(Density_smooth,2,'gaussian',10);
Density_smooth(Density_smooth<2.5e-4)=nan;
%%
figure('Position', [100, 100, 425, 500]);
% ZMesh(ZMesh<5e-3)=nan;
[C,h] = contourf(XMesh/10,YMesh/10,Density',20);
% clabel(C,h,'FontSize',12)
colormap('cool');
xlim([-150,171]);
ylim([-170,170]);
my_plot_setting;
% clim([0.01,0.15]);
% xlim([-45,110]);
% ylim([-90,90]);
set(gca,'fontsize',25);
%%
% figure('Position', [100, 100, 500, 450]);
figure;

% ZMesh(ZMesh<5e-3)=nan;
[C,h] = contourf((XMesh-1.7074e+03)/10000,YMesh/10000,Density_smooth',...
    [0.2*1e-3 0.5*1e-3 0.7*1e-3 1*1e-3 2*1e-3 5*1e-3],"ShowText",true,...
    "LabelSpacing",250);

% [C,h] = contourf(YMesh/10000,(XMesh-1.7074e+03)/10000,Density_smooth',[0.2*1e-3 0.5*1e-3 0.7*1e-3 1*1e-3 2*1e-3 5*1e-3],"ShowText",true);
% axis equal;

clabel(C,h,'FontSize',14)
% colormap('cool');
colormap(slanCM(53));
my_plot_setting;
clim([0.1*1e-3,5*1e-3]);
xlim([-0.4,0]);
ylim([-0.17,0.17]);

% set(gca,'fontsize',20);
%%
my_density = flip(Density(:,36));
my_density = my_density(1:45);
my_x = XMesh(36,:)/10;
my_x = my_x - min(my_x);
my_x = my_x(1:45);
my_x(1) = 1e-6;
% figure('Position', [100, 100, 500, 450]);
figure;
plot(my_x/1000,my_density*100,'ro','LineWidth',1);
my_plot_setting;
xlim([-0.01,0.25]);
ylim([-0.001,0.025]*100);
% set(gca,'fontsize',20);

[xData, yData] = prepareCurveData( my_x, my_density );

% Set up fittype and options.
ft = fittype( 'exp2' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
% opts.StartPoint = [0.0143201297224017 -0.0411304691421361 0.000993144339988178 -0.00378111476232695];

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft, opts );


x = 0.001:0.001:220;
y = fitresult(x);
hold on;

plot(x/1000,y*100,'-r','linewidth',2);
% set(gca,'fontsize',20);
% legend('');
