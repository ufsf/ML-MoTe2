clc;
clear;
%%
load('Vac.mat');
Vac = Vac{1};
x_v = Vac.x_v;
y_v = Vac.y_v;

%%
Num_Vac = length(x_v);
for i = 1
    % file = ['no_vac/',num2str(i),'.data'];
    [atom_tmp,bounds] = read_data('ini.data');
    x = atom_tmp(:,3);
    y = atom_tmp(:,4);
    z = atom_tmp(:,5);
    index_top = find(z>16);
    xv_tmp = x_v(i:end);
    yv_tmp = y_v(i:end);
    Remove_index = [];
    for j = 1:length(xv_tmp)
        xv_tmp_j = xv_tmp(j);
        yv_tmp_j = yv_tmp(j);
        dis_tmp = (x-xv_tmp_j).^2+(y-yv_tmp_j).^2;
        index_tmp = find(dis_tmp.^0.5<1e-2);
        Remove_index(j) = intersect(index_top,index_tmp);
    end
    remain_index = setdiff(1:length(x),Remove_index);
    atom_tmp = atom_tmp(remain_index,:);
    folder = 'vac/';
    write_data([folder,num2str(i-1),'.data'],atom_tmp',bounds);
end
