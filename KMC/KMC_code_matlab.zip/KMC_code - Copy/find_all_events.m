function [All_events, All_phase_type, All_move_atom_id,neight_list,num_neigh] = find_all_events(x_top,...
    y_top,x_bottom,y_bottom,All_move_atom_id_select,neight_list_old,num_neigh_old)
    [neight_list,num_neigh] = build_neighbor_list(x_top,y_top,All_move_atom_id_select,...
        neight_list_old,num_neigh_old);
    move_index = find(num_neigh<5);
    All_events = [];
    All_phase_type = [];
    All_id = [];
    for i = 1:length(move_index)
        curr_index = move_index(i);
        list_i = neight_list{curr_index};
        x_neigh = x_top(list_i);
        y_neigh = y_top(list_i);  
    
        % if length(x_neigh)==2
        %     pause(0.1);
        % end
        x_i = x_top(curr_index);
        y_i = y_top(curr_index);
        [events_i, phase_type_i, id_i] = find_one_events(x_i,y_i,x_neigh,y_neigh,x_bottom,y_bottom,i);
        All_events = [ All_events events_i];
        All_phase_type = [All_phase_type phase_type_i];
        All_id = [All_id id_i];
    end
    All_move_atom_id = move_index(All_id);
end