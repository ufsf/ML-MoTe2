clc;
clear;
%% \NC-DFT-MoTe2\Vacancy_line\make_config_matlab
[atom_ini,bounds] = read_data('VIP-backup/defect-large.data');
%%
pt1_small = [293.021 7.86999];
pt2_small = [277.812 -0.910814];
pt3_small = [293.021 -9.69127];

pt1_large = [294.035 248.459];
pt2_large = [-150.055 -7.93516];
pt3_large = [294.035 -264.33];

%%
atom = atom_ini;
x = atom(:,3);
y = atom(:,4);
z = atom(:,5);
%%
index1 = get_index_new(x,y,z,pt1_large,pt2_large,pt3_large);
index2 = get_index_new(x,y,z,pt1_small,pt2_small,pt3_small);
index_final = setdiff(index1,index2);

Num_Vac = 146*3; % N/2 is the number of divacancy
remove_index = index_final(randperm(length(index_final),Num_Vac));

index_rest = setdiff(1:length(atom_ini),remove_index);
%%
write_data('defect-large-438.data',atom_ini(index_rest,:)',bounds);
