clc;
clear;
%% determine the energy difference between 2H and 1T'
pe_2H = [-220.22705 -220.1463];
pe_1T = [-220.1024 -220.19858];
pe_diff = (pe_2H - pe_1T)/2;
%%
% [atom_defect,bounds] = read_data('VIP-backup/defect-large.data');
num = 146;
[atom_defect,bounds] = read_data(['defect-large-',num2str(num),'.data']);

% [atom_defect,bounds] = read_data('defect-large.datamy');

z_defect = atom_defect(:,end);
top_index = find(z_defect>15.5); % top Te layer
bottom_index = find(z_defect<14); % top Te layer
other_index = find(z_defect<=15.5); % middle Mo and bottom Te layer
% in the following code, we will only work on the top layer
x_top = atom_defect(top_index,3);
y_top = atom_defect(top_index,4);
x_bottom = atom_defect(bottom_index,3);
y_bottom = atom_defect(bottom_index,4);
%% run KMC for gradual phase transitions
kb = 8.617333262e-5;
v0 = 1.5e13;
Temp = 300;
Time = 0;
Time_store(1) = 0;
PT_size = 15;
PT_size_Store(1) = 15;
count = 1;

% find all events
% save the initial 
write_data('0.data',atom_defect',bounds);

All_move_atom_id_select = -1;

neight_list_old = [];
num_neigh_old = [];
flag_forward = 1;

for iStep = 1:1e6
    rng('shuffle')
    % find all the possible events
    [All_events, All_phase_type, All_move_atom_id,neight_list,num_neigh] = find_all_events(x_top,...
        y_top,x_bottom,y_bottom,All_move_atom_id_select,neight_list_old,num_neigh_old);
    % 
    barrier_temp = ones(size(All_phase_type));
    if flag_forward == 1
        barrier_temp(All_phase_type==0) = 0.4;
        barrier_temp(All_phase_type==1) = 0.4+0.0261;
    else
        barrier_temp(All_phase_type==0) = 0.4+0.0623;
        barrier_temp(All_phase_type==1) = 0.4;
    end
    All_rate = v0*exp(-barrier_temp/(kb*Temp));
    All_rate_fake = v0*exp(-barrier_temp./(kb*Temp));
    SumRate = sum(All_rate);
    SumRate_fake = sum(All_rate_fake);
    Cumulative_sum = cumsum(All_rate);
    randRate = rand()*SumRate;
    index = find(Cumulative_sum>=randRate);
    index = index(1); % Only this event will occur in All_rate
    All_move_atom_id_select = All_move_atom_id(index);
    All_events_select = All_events(index);
    All_phase_type_select = All_phase_type(index);

    if All_phase_type_select == 0
        PT_size = PT_size + 1;
    elseif All_phase_type_select == 1
        PT_size = PT_size - 1;
    end
    PT_size_Store(count) = PT_size;

    [x_top,y_top] = displace_atom(All_phase_type_select,All_events_select,...
        All_move_atom_id_select,x_top,y_top);
    temp_rand = rand();
    Time = Time - log(temp_rand)/SumRate;
    Time_store(count+1) = Time;
    count = count + 1;

    if mod(count,500) == 0
        atom_defect(top_index,3) = x_top;
        atom_defect(top_index,4) = y_top;
        write_data([num2str(count),'.data'],atom_defect',bounds);
        Res.Time_store = Time_store;
        Res.PT_size_Store = PT_size_Store;
        save('res.mat','Res');
    end

    if PT_size_Store(end)<= 0
        atom_defect(top_index,3) = x_top;
        atom_defect(top_index,4) = y_top;
        write_data([num2str(count),'.data-vac'],atom_defect',bounds);
    end

    if PT_size_Store(end)>= 10585-num
        atom_defect(top_index,3) = x_top;
        atom_defect(top_index,4) = y_top;
        write_data([num2str(count),'.data-1T'],atom_defect',bounds);
    end

    disp(iStep);

    neight_list_old = neight_list;
    num_neigh_old = num_neigh;

    if PT_size_Store(end)>= 10585-num
        flag_forward = 0;
    elseif PT_size_Store(end)<= 0
        flag_forward = 1;
    end 

end
Res.Time_store = Time_store;
Res.PT_size_Store = PT_size_Store;
save('res.mat','Res');
%%
figure;
load('res.mat');
plot(Res.Time_store(1:end-1),Res.PT_size_Store);