function write_data(out_file,atom,bounds)
Natom = length(atom);
Fid = fopen(out_file, 'w');
fprintf(Fid, '# LAMMPS data file written by Matlab\n');
fprintf(Fid, '%d  atoms\n', Natom);
fprintf(Fid, '2 atom types\n');
fprintf(Fid, '%.12f  %.12f xlo xhi\n',bounds(1,1),bounds(2,1));
fprintf(Fid, '%.12f  %.12f ylo yhi\n',bounds(1,2),bounds(2,2));
fprintf(Fid, '%.12f  %.12f zlo zhi\n',bounds(1,3),bounds(2,3));
fprintf(Fid, '\n');
fprintf(Fid, 'Atoms # atomic\n');
fprintf(Fid, '\n');

fprintf(Fid, '%d %d %.12f %.12f %.12f\n', atom);
fclose(Fid);
end